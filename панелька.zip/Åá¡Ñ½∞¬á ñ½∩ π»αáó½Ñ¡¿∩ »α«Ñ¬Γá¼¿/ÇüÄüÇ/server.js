const express=require('express');
const http=require('http');
const WebSocket=require('ws');
const fs=require('fs');
const path=require('path');
const {spawn,execFileSync,execFile}=require('child_process');
const {promisify}=require('util');
const execFileAsync=promisify(execFile);
const os=require('os');
const jwt=require('jsonwebtoken');
const bcrypt=require('bcryptjs');
const Database=require('better-sqlite3');
const multer=require('multer');
const archiver=require('archiver');
const unzipper=require('unzipper');
const cron=require('node-cron');
const pidusage=require('pidusage');
const EventEmitter=require('events');

const ROOT=__dirname;
const cfg=JSON.parse(fs.readFileSync(path.join(ROOT,'config.json'),'utf8'));
if(!cfg.jwtSecret||cfg.jwtSecret==='CHANGE_THIS_SECRET_TO_A_LONG_RANDOM_VALUE'||String(cfg.jwtSecret).length<32){
  cfg.jwtSecret=require('crypto').randomBytes(48).toString('hex');
  try{fs.writeFileSync(path.join(ROOT,'config.json'),JSON.stringify(cfg,null,2));console.log('jwtSecret был небезопасным — сгенерирован новый и сохранён в config.json')}catch(e){console.warn('Не удалось сохранить jwtSecret:',e.message)}
}
const FILE_ROOT=path.resolve(ROOT,cfg.fileRoot);
const BACKUP_ROOT=path.resolve(ROOT,cfg.backupRoot);
const LOG_ROOT=path.resolve(ROOT,cfg.logRoot||'./storage/logs');
fs.mkdirSync(FILE_ROOT,{recursive:true});
fs.mkdirSync(BACKUP_ROOT,{recursive:true});
fs.mkdirSync(LOG_ROOT,{recursive:true});

const db=new Database(path.join(ROOT,'server.db'));
db.pragma('journal_mode=WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password_hash TEXT,role TEXT);
CREATE TABLE IF NOT EXISTS apps(id INTEGER PRIMARY KEY,name TEXT,type TEXT,command TEXT,working_dir TEXT,runtime TEXT,runtime_path TEXT,stop_command TEXT,env_json TEXT,auto_start INTEGER,auto_restart INTEGER,restart_delay INTEGER,max_restarts INTEGER,port INTEGER);
CREATE TABLE IF NOT EXISTS profiles(id INTEGER PRIMARY KEY,app_id INTEGER,name TEXT,command TEXT,runtime_path TEXT,env_json TEXT);
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY,name TEXT,cron TEXT,app_id INTEGER,action TEXT,enabled INTEGER);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,username TEXT,action TEXT,details TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
if(!db.prepare('SELECT 1 FROM users WHERE username=?').get('admin')) db.prepare('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)').run('admin',bcrypt.hashSync('admin',12),'admin');

const procs=new Map();
const jobs=new Map();
const events=new EventEmitter();
const app=express();
const server=http.createServer(app);
const wss=new WebSocket.Server({server,path:'/ws'});
app.use(express.json({limit:'10mb'}));
app.use(express.static(path.join(ROOT,'public')));

function safe(p){
  const root=path.resolve(FILE_ROOT);
  const target=path.resolve(root,p||'');
  if(target!==root&&!target.startsWith(root+path.sep)) throw Error('Недопустимый путь');
  return target;
}
function auth(req,res,next){
  try{
    let token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
    const userFromQuery=req.path==='/api/download'&&req.query.token;
    if(!token&&userFromQuery) token=String(userFromQuery);
    const decoded=jwt.verify(token,cfg.jwtSecret);
    req.user=db.prepare('SELECT id,username,role FROM users WHERE id=?').get(decoded.id);
    if(!req.user) throw Error();
    next();
  }catch{res.status(401).json({error:'Требуется авторизация'});}
}
function admin(req,res,next){if(req.user?.role!=='admin')return res.status(403).json({error:'Требуются права администратора'});next();}
function audit(user,action,details=''){db.prepare('INSERT INTO audit(username,action,details) VALUES(?,?,?)').run(user?.username||'system',action,details);}
function num(v,def,min=0){if(v===''||v==null)return def;const n=Number(v);return Number.isFinite(n)?Math.max(min,Math.trunc(n)):def}
function parseEnv(s){try{return JSON.parse(s||'{}')}catch{return {}}}
let rtCache=null,rtTime=0;
function runtime(force=false){
  if(!force&&rtCache&&Date.now()-rtTime<15000)return rtCache;
  const out=[];
  for(const [key,label,bin] of [['node','Node.js','node'],['npm','npm','npm'],['python','Python','python'],['python3','Python','python3'],['java','Java','java'],['dotnet','.NET','dotnet'],['git','Git','git'],['docker','Docker','docker']]){
    try{
      const p=execFileSync(process.platform==='win32'?'where':'which',[bin],{encoding:'utf8',windowsHide:true}).split(/\r?\n/)[0].trim();
      if(p&&!out.some(x=>x.key===key)){
        let version='';try{version=execFileSync(p,['--version'],{encoding:'utf8',windowsHide:true}).trim().split(/\r?\n/)[0]}catch{}
        out.push({key,label,path:p,version});
      }
    }catch{}
  }
  rtCache=out;rtTime=Date.now();
  return out;
}
function infer(command,cwd){
  const s=(command||'').toLowerCase(),a=[];
  if(/java|\.jar|minecraft/.test(s))a.push('java');
  if(/node|npm|\.js|package\.json/.test(s)||fs.existsSync(path.join(cwd||'','package.json')))a.push('node');
  if(/python|\.py/.test(s)||fs.existsSync(path.join(cwd||'','requirements.txt'))||fs.existsSync(path.join(cwd||'','pyproject.toml')))a.push('python');
  if(/dotnet|\.dll|\.csproj/.test(s))a.push('dotnet');
  return [...new Set(a)];
}
function detectProject(cwd){
  const dir=path.resolve(cwd||'.');
  const exists=n=>fs.existsSync(path.join(dir,n));
  const files=fs.existsSync(dir)?fs.readdirSync(dir):[];
  const result={cwd:dir,type:'auto',command:'',runtime:'',runtimePath:'',detected:[],confidence:'low'};
  if(exists('docker-compose.yml')||exists('compose.yaml')||exists('compose.yml')){result.type='docker';result.command='docker compose up';result.runtime='docker';result.detected.push('Docker Compose');result.confidence='high';return result;}
  if(files.some(x=>x.toLowerCase().endsWith('.jar'))){const jar=files.find(x=>x.toLowerCase().endsWith('.jar'));result.type='minecraft';result.command=`java -jar "${jar}"`;result.runtime='java';result.detected.push(jar);result.confidence='high';return result;}
  if(exists('package.json')){result.type='node';result.command='npm start';result.runtime='node';result.detected.push('package.json');result.confidence='high';return result;}
  if(exists('requirements.txt')||exists('pyproject.toml')){result.type='python';result.command=exists('pyproject.toml')?'python -m app':'python main.py';result.runtime='python';result.detected.push(exists('requirements.txt')?'requirements.txt':'pyproject.toml');result.confidence='medium';return result;}
  const dll=files.find(x=>x.toLowerCase().endsWith('.dll'));if(dll){result.type='dotnet';result.command=`dotnet "${dll}"`;result.runtime='dotnet';result.detected.push(dll);result.confidence='high';return result;}
  const exe=files.find(x=>x.toLowerCase().endsWith('.exe'));if(exe){result.type='executable';result.command=`"${exe}"`;result.detected.push(exe);result.confidence='medium';return result;}
  const bat=files.find(x=>/\.(bat|cmd|sh)$/i.test(x));if(bat){result.type='script';result.command=`"${bat}"`;result.detected.push(bat);result.confidence='medium';return result;}
  return result;
}

function scanProject(cwd){
  const root=path.resolve(cwd||'.');
  if(!fs.existsSync(root)||!fs.statSync(root).isDirectory()) throw Error('Папка не найдена: '+root);
  const candidates=[]; const seen=new Set();
  const add=(type,command,runtime,label,confidence='medium',details='')=>{
    const key=type+'|'+command; if(seen.has(key))return; seen.add(key); candidates.push({type,command,runtime:runtime||'',label,confidence,details});
  };
  const walk=(dir,depth)=>{
    if(depth>2)return;
    let entries=[]; try{entries=fs.readdirSync(dir,{withFileTypes:true})}catch{return}
    for(const e of entries){
      if(e.name.startsWith('.')||['node_modules','venv','.venv','bin','obj','storage'].includes(e.name))continue;
      const full=path.join(dir,e.name), rel=path.relative(root,full)||e.name;
      if(e.isDirectory()){walk(full,depth+1);continue}
      const low=e.name.toLowerCase();
      if(low==='start.bat'||low==='start.cmd')add('script',`"${rel}"`,'',`Запустить ${e.name}`,'high','Windows script');
      if(low==='start.sh')add('script',`sh "${rel}"`,'',`Запустить ${e.name}`,'high','Shell script');
      if(low.endsWith('.jar'))add('minecraft',`java -jar "${rel}"`,'java',`Java JAR: ${e.name}`,'high','JAR application');
      if(low.endsWith('.exe'))add('executable',`"${rel}"`,'',`EXE: ${e.name}`,'medium','Executable');
      if(low.endsWith('.dll'))add('dotnet',`dotnet "${rel}"`,'dotnet',`.NET: ${e.name}`,'high','DLL');
    }
  };
  let pkg=null; try{pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'))}catch{}
  if(pkg){
    const scripts=pkg.scripts||{};
    if(scripts.start)add('node','npm start','node','Node.js: npm start','high',`package.json script: ${scripts.start}`);
    for(const [name,cmd] of Object.entries(scripts)) if(name!=='start') add('node',`npm run ${name}`,'node',`Node.js: npm run ${name}`,'medium',String(cmd));
  }
  if(fs.existsSync(path.join(root,'requirements.txt'))) add('python','python -m pip install -r requirements.txt && python main.py','python','Python: requirements.txt','high','requirements.txt');
  if(fs.existsSync(path.join(root,'pyproject.toml'))) add('python','python -m app','python','Python: pyproject.toml','medium','pyproject.toml');
  if(fs.existsSync(path.join(root,'docker-compose.yml'))||fs.existsSync(path.join(root,'compose.yml'))||fs.existsSync(path.join(root,'compose.yaml'))) add('docker','docker compose up','docker','Docker Compose','high','Compose project');
  walk(root,0);
  if(!candidates.length)add('executable','', '', 'Ручная настройка','low','Автоматический запуск не найден');
  const runtimes=runtime();
  return {cwd:root,candidates:candidates.map(x=>({...x,availableRuntime:!x.runtime||runtimes.some(r=>r.key===x.runtime)})),runtimes};
}

function stat(a){const s=procs.get(a.id);return{running:!!s,pid:s?.child.pid||null,uptime:s?Date.now()-s.startedAt:0,restarts:s?.restarts||0};}
function allApps(){return db.prepare('SELECT * FROM apps ORDER BY id DESC').all().map(a=>({...a,...stat(a)}));}
function broadcast(x){events.emit(x.type,x);for(const client of wss.clients)if(client.readyState===WebSocket.OPEN)client.send(JSON.stringify(x));}
function appendOutput(id,stream,data){const text=String(data??'');const s=procs.get(id);if(s){s.history.push({stream,data:text,time:Date.now()});if(s.history.length>500)s.history.shift();}try{fs.appendFileSync(path.join(LOG_ROOT,`app-${id}.log`),`[${new Date().toISOString()}] [${stream}] ${text}`,'utf8')}catch{}broadcast({type:'output',id,stream,data:text});}
function start(a,existingState=null){
  if(procs.has(a.id)) throw Error('Уже запущено');
  const cwd=path.resolve(a.working_dir);
  if(!fs.existsSync(cwd)||!fs.statSync(cwd).isDirectory()) throw Error('Рабочая папка не найдена: '+cwd);
  const env={...process.env,...parseEnv(a.env_json)};
  if(a.runtime_path){const runtimeDir=fs.statSync(a.runtime_path).isDirectory()?a.runtime_path:path.dirname(a.runtime_path);env.PATH=runtimeDir+path.delimiter+(env.PATH||'');}
  const state=existingState||{restarts:0,history:[],startedAt:Date.now(),stableTimer:null,manualStop:false};
  state.manualStop=false;state.startedAt=Date.now();
  const child=spawn(a.command,{cwd,shell:true,windowsHide:true,env,stdio:['pipe','pipe','pipe'],detached:process.platform!=='win32'});
  state.child=child;procs.set(a.id,state);
  appendOutput(a.id,'system',`[Server Manager] Запуск PID ${child.pid}\n`);
  child.stdout.on('data',d=>appendOutput(a.id,'stdout',d));
  child.stderr.on('data',d=>appendOutput(a.id,'stderr',d));
  child.on('error',err=>appendOutput(a.id,'stderr',`[process error] ${err.message}\n`));
  child.stdin.on('error',()=>{});
  state.stableTimer=setTimeout(()=>{state.restarts=0;},30000);
  child.on('close',code=>{
    clearTimeout(state.stableTimer);
    procs.delete(a.id);
    broadcast({type:'exit',id:a.id,code});
    appendOutput(a.id,'system',`[Server Manager] Процесс завершён с кодом ${code}\n`);
    if(!state.manualStop&&a.auto_restart&&state.restarts<a.max_restarts){
      state.restarts++;
      appendOutput(a.id,'system',`[Server Manager] Автоперезапуск ${state.restarts}/${a.max_restarts} через ${a.restart_delay} сек.\n`);
      setTimeout(()=>{try{start(a,state)}catch(e){broadcast({type:'error',id:a.id,error:e.message});}},Math.max(0,a.restart_delay)*1000);
    }
  });
  return {running:true,pid:child.pid};
}
function stop(a,kill=false){
  const s=procs.get(a.id);if(!s)return false;
  s.manualStop=true;
  if(!kill&&a.stop_command){const sp=spawn(a.stop_command,{cwd:a.working_dir,shell:true,windowsHide:true,stdio:'ignore'});sp.on('error',e=>appendOutput(a.id,'stderr',`[stop_command error] ${e.message}\n`));return true;}
  if(process.platform==='win32')spawn('taskkill',['/F','/T','/PID',String(s.child.pid)],{windowsHide:true});
  else{const sig=kill?'SIGKILL':'SIGTERM';try{process.kill(-s.child.pid,sig)}catch{try{s.child.kill(sig)}catch{}}}
  return true;
}
function waitForExit(id,timeout=10000){return new Promise(resolve=>{if(!procs.has(id))return resolve(true);const started=Date.now();const timer=setInterval(()=>{if(!procs.has(id)){clearInterval(timer);resolve(true)}else if(Date.now()-started>=timeout){clearInterval(timer);resolve(false)}},100);});}
async function restart(a){if(procs.has(a.id)){stop(a,false);const done=await waitForExit(a.id,10000);if(!done){stop(a,true);await waitForExit(a.id,3000)}}return start(a);}
async function createBackup(a){
  const source=path.resolve(a.working_dir);if(!fs.existsSync(source))throw Error('Рабочая папка не найдена');
  const name=`app-${a.id}-${Date.now()}.zip`,dest=path.join(BACKUP_ROOT,name);
  await new Promise((resolve,reject)=>{const out=fs.createWriteStream(dest);const archive=archiver('zip',{zlib:{level:6}});out.on('close',resolve);out.on('error',reject);archive.on('error',reject);archive.pipe(out);archive.directory(source,false);archive.finalize();});
  return{name,path:dest,size:fs.statSync(dest).size,modified:new Date().toISOString()};
}
async function restoreBackup(file,target){
  const abs=path.resolve(BACKUP_ROOT,path.basename(file));
  if(!abs.startsWith(BACKUP_ROOT+path.sep))throw Error('Недопустимый backup');
  if(!fs.existsSync(abs))throw Error('Backup не найден');
  const dir=await unzipper.Open.file(abs);
  for(const entry of dir.files){
    const dest=path.resolve(target,entry.path);
    if(dest!==path.resolve(target)&&!dest.startsWith(path.resolve(target)+path.sep))throw Error('Backup содержит недопустимый путь');
    if(entry.type==='Directory'){fs.mkdirSync(dest,{recursive:true});continue;}
    fs.mkdirSync(path.dirname(dest),{recursive:true});
    await new Promise((resolve,reject)=>entry.stream().pipe(fs.createWriteStream(dest)).on('finish',resolve).on('error',reject));
  }
}

app.post('/api/login',(q,r)=>{const {username,password}=q.body||{};const u=db.prepare('SELECT * FROM users WHERE username=?').get(username);if(!u||!bcrypt.compareSync(password||'',u.password_hash))return r.status(401).json({error:'Неверный логин или пароль'});r.json({token:jwt.sign({id:u.id},cfg.jwtSecret,{expiresIn:'12h'}),user:{id:u.id,username:u.username,role:u.role}})});
app.get('/api/me',auth,(q,r)=>r.json(q.user));
app.get('/api/apps',auth,(q,r)=>r.json(allApps()));
app.get('/api/apps/:id',auth,(q,r)=>{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(+q.params.id);if(!a)return r.status(404).json({error:'Не найдено'});r.json({...a,...stat(a),profiles:db.prepare('SELECT * FROM profiles WHERE app_id=? ORDER BY id').all(a.id)})});
app.post('/api/apps',auth,(q,r)=>{const b=q.body||{};if(!b.name||!b.command||!b.working_dir)return r.status(400).json({error:'Название, команда и рабочая папка обязательны'});const x=db.prepare(`INSERT INTO apps(name,type,command,working_dir,runtime,runtime_path,stop_command,env_json,auto_start,auto_restart,restart_delay,max_restarts,port) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(b.name,b.type||'auto',b.command,b.working_dir,b.runtime||'',b.runtime_path||'',b.stop_command||'',JSON.stringify(b.env||{}),b.auto_start?1:0,b.auto_restart?1:0,num(b.restart_delay,5),num(b.max_restarts,5),num(b.port,null,1));const a=db.prepare('SELECT * FROM apps WHERE id=?').get(x.lastInsertRowid);audit(q.user,'app_create',a.name);r.json(a)});
app.post('/api/apps/import',auth,(q,r)=>{try{const b=q.body||{},d=scanProject(b.working_dir);const c=d.candidates[Number.isInteger(+b.candidate)?+b.candidate:0];if(!c||!c.command)return r.status(400).json({error:'Не выбран способ запуска'});const name=b.name||path.basename(d.cwd)||'Новое приложение';const x=db.prepare(`INSERT INTO apps(name,type,command,working_dir,runtime,runtime_path,stop_command,env_json,auto_start,auto_restart,restart_delay,max_restarts,port) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(name,c.type,c.command,d.cwd,c.runtime||'',b.runtime_path||'',b.stop_command||'',JSON.stringify(b.env||{}),b.auto_start?1:0,b.auto_restart?1:0,num(b.restart_delay,5),num(b.max_restarts,5),num(b.port,null,1));const a=db.prepare('SELECT * FROM apps WHERE id=?').get(x.lastInsertRowid);audit(q.user,'app_import',`${a.name}: ${c.label}`);r.json({...a,detected:d,candidate:c})}catch(e){r.status(400).json({error:e.message})}});
app.put('/api/apps/:id',auth,(q,r)=>{const id=+q.params.id,o=db.prepare('SELECT * FROM apps WHERE id=?').get(id),b=q.body||{};if(!o)return r.status(404).json({error:'Не найдено'});if(procs.has(id))return r.status(409).json({error:'Сначала остановите приложение'});db.prepare(`UPDATE apps SET name=?,type=?,command=?,working_dir=?,runtime=?,runtime_path=?,stop_command=?,env_json=?,auto_start=?,auto_restart=?,restart_delay=?,max_restarts=?,port=? WHERE id=?`).run(b.name??o.name,b.type??o.type,b.command??o.command,b.working_dir??o.working_dir,b.runtime??o.runtime,b.runtime_path??o.runtime_path,b.stop_command??o.stop_command,JSON.stringify(b.env??parseEnv(o.env_json)),b.auto_start==null?o.auto_start:b.auto_start?1:0,b.auto_restart==null?o.auto_restart:b.auto_restart?1:0,num(b.restart_delay,o.restart_delay),num(b.max_restarts,o.max_restarts),b.port===undefined?o.port:num(b.port,null,1),id);r.json(db.prepare('SELECT * FROM apps WHERE id=?').get(id))});
app.delete('/api/apps/:id',auth,(q,r)=>{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(+q.params.id);if(!a)return r.status(404).json({error:'Не найдено'});stop(a,true);db.prepare('DELETE FROM profiles WHERE app_id=?').run(a.id);for(const t of db.prepare('SELECT id FROM tasks WHERE app_id=?').all(a.id)){jobs.get(t.id)?.stop();jobs.delete(t.id)}db.prepare('DELETE FROM tasks WHERE app_id=?').run(a.id);db.prepare('DELETE FROM apps WHERE id=?').run(a.id);audit(q.user,'app_delete',a.name);r.json({ok:true})});
for(const [route,fn] of [['start',a=>start(a)],['stop',a=>stop(a)],['kill',a=>stop(a,true)]])app.post('/api/apps/:id/'+route,auth,(q,r)=>{try{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(+q.params.id);if(!a)return r.status(404).json({error:'Не найдено'});fn(a);audit(q.user,route,a.name);r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/apps/:id/restart',auth,async(q,r)=>{try{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(+q.params.id);if(!a)return r.status(404).json({error:'Не найдено'});await restart(a);audit(q.user,'restart',a.name);r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/apps/:id/command',auth,(q,r)=>{const s=procs.get(+q.params.id);if(!s?.child.stdin.writable)return r.status(400).json({error:'Процесс не принимает команды'});s.child.stdin.write(String(q.body.command||'')+'\n');r.json({ok:true})});
app.get('/api/apps/:id/output',auth,(q,r)=>{const s=procs.get(+q.params.id);r.json(s?.history||[])});
async function pidTree(root){
  try{
    const {stdout}=await execFileAsync('ps',['-A','-o','pid=,ppid='],{timeout:5000});
    const kids=new Map();for(const l of stdout.split('\n')){const m=l.trim().split(/\s+/).map(Number);if(m.length===2&&!m.some(isNaN)){if(!kids.has(m[1]))kids.set(m[1],[]);kids.get(m[1]).push(m[0])}}
    const out=[root],queue=[root];while(queue.length){const p=queue.shift();for(const c of kids.get(p)||[]){out.push(c);queue.push(c)}}
    return out;
  }catch{return [root]}
}
async function posixStats(root){
  const pids=await pidTree(root);
  try{
    const res=await pidusage(pids);let cpu=0,memory=0;
    for(const k of Object.keys(res)){cpu+=res[k]?.cpu||0;memory+=res[k]?.memory||0}
    return {cpu,memory};
  }catch{
    const {stdout}=await execFileAsync('ps',['-o','%cpu=,rss=','-p',pids.join(',')],{timeout:5000});
    let cpu=0,memory=0;for(const l of stdout.split('\n')){const m=l.trim().split(/\s+/).map(Number);if(m.length===2&&!m.some(isNaN)){cpu+=m[0];memory+=m[1]*1024}}
    return {cpu,memory};
  }
}
// Windows: pidusage использует wmic, которого нет в новых Windows 11 — берём данные через PowerShell/CIM.
let winSnap=null;const winPrev=new Map();
async function winProcesses(){
  if(winSnap&&Date.now()-winSnap.time<1500)return winSnap;
  const {stdout}=await execFileAsync('powershell.exe',['-NoProfile','-NonInteractive','-Command','Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,WorkingSetSize,UserModeTime,KernelModeTime | ConvertTo-Json -Compress'],{timeout:15000,windowsHide:true,maxBuffer:64*1024*1024});
  let list=JSON.parse(stdout||'[]');if(!Array.isArray(list))list=[list];
  winSnap={time:Date.now(),list};return winSnap;
}
async function winStats(root){
  const snap=await winProcesses();
  const kids=new Map(),byPid=new Map();
  for(const p of snap.list){byPid.set(p.ProcessId,p);if(!kids.has(p.ParentProcessId))kids.set(p.ParentProcessId,[]);kids.get(p.ParentProcessId).push(p.ProcessId)}
  const seen=new Set([root]),queue=[root];let memory=0,cpuTime=0;
  while(queue.length){const pid=queue.shift(),p=byPid.get(pid);if(p){memory+=Number(p.WorkingSetSize)||0;cpuTime+=(Number(p.UserModeTime)||0)+(Number(p.KernelModeTime)||0)}for(const c of kids.get(pid)||[])if(!seen.has(c)){seen.add(c);queue.push(c)}}
  const prev=winPrev.get(root);let cpu=prev?.cpu??0;
  if(!prev||snap.time>prev.time){if(prev)cpu=Math.max(0,(cpuTime-prev.cpuTime)/10000/(snap.time-prev.time)*100);winPrev.set(root,{time:snap.time,cpuTime,cpu})}
  return {cpu,memory};
}
let sysCpu=0,sysPrev=os.cpus();
setInterval(()=>{const now=os.cpus();let idle=0,total=0;now.forEach((c,i)=>{const p=sysPrev[i]||c;for(const k in c.times)total+=c.times[k]-p.times[k];idle+=c.times.idle-p.times.idle});sysPrev=now;if(total>0)sysCpu=Math.min(100,Math.max(0,(1-idle/total)*100))},2000).unref();
app.get('/api/system',auth,(q,r)=>r.json({cpu:sysCpu,cores:os.cpus().length,memTotal:os.totalmem(),memUsed:os.totalmem()-os.freemem()}));
app.get('/api/apps/:id/stats',auth,async(q,r)=>{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(+q.params.id),s=procs.get(a?.id);if(!s)return r.json({cpu:0,memory:0});try{r.json(process.platform==='win32'?await winStats(s.child.pid):await posixStats(s.child.pid))}catch(e){console.warn('stats error:',e.message);r.json({cpu:0,memory:0,error:e.message})}});
app.post('/api/apps/:id/backup',auth,async(q,r)=>{try{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(+q.params.id);if(!a)return r.status(404).json({error:'Не найдено'});const b=await createBackup(a);audit(q.user,'backup_create',`${a.name}: ${b.name}`);r.json(b)}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/apps/:id/restore',auth,async(q,r)=>{try{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(+q.params.id);if(!a)return r.status(404).json({error:'Не найдено'});if(procs.has(a.id))return r.status(409).json({error:'Сначала остановите приложение'});await restoreBackup(q.body.name,a.working_dir);audit(q.user,'backup_restore',`${a.name}: ${q.body.name}`);r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.get('/api/backups',auth,(q,r)=>{try{r.json(fs.readdirSync(BACKUP_ROOT).filter(n=>n.toLowerCase().endsWith('.zip')).map(n=>{const s=fs.statSync(path.join(BACKUP_ROOT,n));return{name:n,size:s.size,modified:s.mtime}}).sort((a,b)=>b.modified-a.modified))}catch(e){r.status(400).json({error:e.message})}});
app.delete('/api/backups/:name',auth,(q,r)=>{try{const n=path.basename(q.params.name);fs.rmSync(path.join(BACKUP_ROOT,n),{force:true});audit(q.user,'backup_delete',n);r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.get('/api/runtimes',auth,(q,r)=>r.json(runtime(true)));
app.post('/api/runtimes/suggest',auth,(q,r)=>{const rt=runtime();r.json(infer(q.body.command,q.body.cwd).map(k=>({key:k,candidates:rt.filter(x=>x.key===k)})))});
app.post('/api/detect',auth,(q,r)=>{try{const d=detectProject(q.body.cwd);d.runtimes=runtime().filter(x=>x.key===d.runtime);r.json(d)}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/scan',auth,(q,r)=>{try{r.json(scanProject(q.body.cwd))}catch(e){r.status(400).json({error:e.message})}});
app.get('/api/browse',auth,admin,(q,r)=>{try{const requested=q.query.path||'';if(!requested){if(process.platform==='win32'){const drives=[];for(let c=65;c<=90;c++){const d=String.fromCharCode(c)+':\\';try{if(fs.existsSync(d))drives.push({name:d,type:'directory',path:d})}catch{}}return r.json(drives)}return r.json(fs.readdirSync('/',{withFileTypes:true}).map(e=>({name:e.name,type:e.isDirectory()?'directory':'file',path:path.join('/',e.name)})));}const target=path.resolve(requested);if(!fs.existsSync(target)||!fs.statSync(target).isDirectory())return r.status(400).json({error:'Папка не найдена'});r.json(fs.readdirSync(target,{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>({name:e.name,type:'directory',path:path.join(target,e.name)})));}catch(e){r.status(400).json({error:e.message})}});
app.get('/api/files',auth,(q,r)=>{try{const dir=safe(q.query.path||'');r.json(fs.readdirSync(dir,{withFileTypes:true}).map(e=>{const p=path.join(dir,e.name),s=fs.statSync(p);return{name:e.name,type:e.isDirectory()?'directory':'file',size:s.size,modified:s.mtime}}).sort((a,b)=>a.type===b.type?a.name.localeCompare(b.name):a.type==='directory'?-1:1))}catch(e){r.status(400).json({error:e.message})}});
app.get('/api/file',auth,(q,r)=>{try{const p=safe(q.query.path);if(fs.statSync(p).isDirectory())throw Error('Это папка');r.json({content:fs.readFileSync(p,'utf8')})}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/file',auth,(q,r)=>{try{fs.writeFileSync(safe(q.body.path),q.body.content??'','utf8');r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.delete('/api/file',auth,(q,r)=>{try{fs.rmSync(safe(q.body.path),{recursive:true,force:true});r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/mkdir',auth,(q,r)=>{try{fs.mkdirSync(safe(q.body.path),{recursive:true});r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/rename',auth,(q,r)=>{try{fs.renameSync(safe(q.body.oldPath),safe(q.body.newPath));r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});
const upload=multer({dest:path.join(ROOT,'.uploads'),limits:{fileSize:(cfg.maxUploadMb||512)*1024*1024}});fs.mkdirSync(path.join(ROOT,'.uploads'),{recursive:true});
app.post('/api/upload',auth,upload.single('file'),(q,r)=>{try{const dest=path.join(safe(q.body.path||''),path.basename(q.file.originalname));fs.renameSync(q.file.path,dest);r.json({ok:true})}catch(e){if(q.file)try{fs.unlinkSync(q.file.path)}catch{}r.status(400).json({error:e.message})}});
app.get('/api/download',auth,(q,r)=>{try{r.download(safe(q.query.path))}catch(e){r.status(400).json({error:e.message})}});
app.get('/api/apps/:id/profiles',auth,(q,r)=>{const id=+q.params.id;if(!db.prepare('SELECT 1 FROM apps WHERE id=?').get(id))return r.status(404).json({error:'Приложение не найдено'});r.json(db.prepare('SELECT * FROM profiles WHERE app_id=? ORDER BY id').all(id));});
app.post('/api/apps/:id/profiles',auth,(q,r)=>{const id=+q.params.id,b=q.body||{};if(!db.prepare('SELECT 1 FROM apps WHERE id=?').get(id))return r.status(404).json({error:'Приложение не найдено'});if(!b.name||!b.command)return r.status(400).json({error:'Название и команда обязательны'});const x=db.prepare('INSERT INTO profiles(app_id,name,command,runtime_path,env_json) VALUES(?,?,?,?,?)').run(id,b.name,b.command,b.runtime_path||'',JSON.stringify(b.env||{}));audit(q.user,'profile_create',`${id}: ${b.name}`);r.json(db.prepare('SELECT * FROM profiles WHERE id=?').get(x.lastInsertRowid));});
app.put('/api/profiles/:id',auth,(q,r)=>{const id=+q.params.id,b=q.body||{};const old=db.prepare('SELECT * FROM profiles WHERE id=?').get(id);if(!old)return r.status(404).json({error:'Профиль не найден'});db.prepare('UPDATE profiles SET name=?,command=?,runtime_path=?,env_json=? WHERE id=?').run(b.name??old.name,b.command??old.command,b.runtime_path??old.runtime_path,JSON.stringify(b.env??parseEnv(old.env_json)),id);r.json(db.prepare('SELECT * FROM profiles WHERE id=?').get(id));});
app.delete('/api/profiles/:id',auth,(q,r)=>{db.prepare('DELETE FROM profiles WHERE id=?').run(+q.params.id);r.json({ok:true});});
app.post('/api/apps/:id/profiles/:profileId/apply',auth,(q,r)=>{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(+q.params.id),p=db.prepare('SELECT * FROM profiles WHERE id=? AND app_id=?').get(+q.params.profileId,+q.params.id);if(!a||!p)return r.status(404).json({error:'Не найдено'});if(procs.has(a.id))return r.status(409).json({error:'Сначала остановите приложение'});db.prepare('UPDATE apps SET command=?,runtime_path=?,env_json=? WHERE id=?').run(p.command,p.runtime_path,p.env_json,a.id);audit(q.user,'profile_apply',`${a.name}: ${p.name}`);r.json(db.prepare('SELECT * FROM apps WHERE id=?').get(a.id));});

app.get('/api/apps/:id/log',auth,(q,r)=>{try{const file=path.join(LOG_ROOT,`app-${+q.params.id}.log`);if(!fs.existsSync(file))return r.type('text').send('');const text=fs.readFileSync(file,'utf8');r.type('text').send(text.slice(-100000));}catch(e){r.status(400).json({error:e.message})}});
app.delete('/api/apps/:id/log',auth,(q,r)=>{try{fs.rmSync(path.join(LOG_ROOT,`app-${+q.params.id}.log`),{force:true});r.json({ok:true})}catch(e){r.status(400).json({error:e.message})}});

async function dockerCommand(args){try{return await execFileAsync(process.platform==='win32'?'docker':'docker',args,{timeout:30000,windowsHide:true,maxBuffer:5*1024*1024});}catch(e){throw Error((e.stderr||e.message||'Docker error').trim());}}
app.get('/api/docker',auth,async(q,r)=>{try{const {stdout}=await dockerCommand(['ps','-a','--format','{{json .}}']);const rows=stdout.split(/\r?\n/).filter(Boolean).map(x=>JSON.parse(x));r.json(rows);}catch(e){r.status(400).json({error:e.message})}});
app.post('/api/docker/run',auth,async(q,r)=>{try{const b=q.body||{};if(!b.image)return r.status(400).json({error:'Image обязательен'});const args=['run','-d','--name',String(b.name||`sm-${Date.now()}`)];if(b.ports){for(const p of String(b.ports).split(',').map(x=>x.trim()).filter(Boolean))args.push('-p',p)}args.push(b.image);if(b.command)args.push(...String(b.command).split(/\s+/));const {stdout}=await dockerCommand(args);audit(q.user,'docker_run',b.name||b.image);r.json({id:stdout.trim()});}catch(e){r.status(400).json({error:e.message})}});
for(const action of ['start','stop','restart','remove'])app.post(`/api/docker/:id/${action}`,auth,async(q,r)=>{try{const id=String(q.params.id);const args=action==='remove'?['rm','-f',id]:[action,id];await dockerCommand(args);audit(q.user,`docker_${action}`,id);r.json({ok:true});}catch(e){r.status(400).json({error:e.message})}});
app.get('/api/docker/:id/logs',auth,async(q,r)=>{try{const {stdout,stderr}=await dockerCommand(['logs','--tail','500',String(q.params.id)]);r.type('text').send((stdout||'')+(stderr||''));}catch(e){r.status(400).json({error:e.message})}});
app.get('/api/tasks',auth,(q,r)=>r.json(db.prepare('SELECT * FROM tasks ORDER BY id DESC').all()));
function registerTask(t){if(!cron.validate(t.cron))return;jobs.get(t.id)?.stop();jobs.set(t.id,cron.schedule(t.cron,async()=>{const a=db.prepare('SELECT * FROM apps WHERE id=?').get(t.app_id);if(!a)return;try{if(t.action==='start')start(a);if(t.action==='stop')stop(a);if(t.action==='restart')await restart(a)}catch(e){broadcast({type:'task_error',id:t.id,error:e.message})}}));}
app.post('/api/tasks',auth,(q,r)=>{const b=q.body||{};if(!b.name)return r.status(400).json({error:'Название обязательно'});if(!cron.validate(b.cron))return r.status(400).json({error:'Некорректный Cron'});if(!['start','stop','restart'].includes(b.action))return r.status(400).json({error:'Недопустимое действие'});if(!db.prepare('SELECT 1 FROM apps WHERE id=?').get(+b.app_id))return r.status(400).json({error:'Приложение не найдено'});const x=db.prepare('INSERT INTO tasks(name,cron,app_id,action,enabled) VALUES(?,?,?,?,?)').run(b.name,b.cron,+b.app_id,b.action,1);const t=db.prepare('SELECT * FROM tasks WHERE id=?').get(x.lastInsertRowid);registerTask(t);r.json(t)});
app.delete('/api/tasks/:id',auth,(q,r)=>{const id=+q.params.id;jobs.get(id)?.stop();jobs.delete(id);db.prepare('DELETE FROM tasks WHERE id=?').run(id);r.json({ok:true})});
app.get('/api/audit',auth,(q,r)=>r.json(db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT 500').all()));
app.post('/api/password',auth,(q,r)=>{const u=db.prepare('SELECT * FROM users WHERE id=?').get(q.user.id);if(!bcrypt.compareSync(q.body.currentPassword||'',u.password_hash))return r.status(400).json({error:'Текущий пароль неверен'});if(String(q.body.newPassword||'').length<8)return r.status(400).json({error:'Новый пароль должен содержать минимум 8 символов'});db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(q.body.newPassword,12),u.id);r.json({ok:true})});

wss.on('connection',(socket,req)=>{try{const u=new URL(req.url,'http://localhost');const token=u.searchParams.get('token');const decoded=jwt.verify(token,cfg.jwtSecret);if(!db.prepare('SELECT 1 FROM users WHERE id=?').get(decoded.id))throw Error();socket.send(JSON.stringify({type:'hello'}));for(const [id,s] of procs){for(const h of s.history)socket.send(JSON.stringify({type:'output',id,stream:h.stream,data:h.data,time:h.time}))}}catch{socket.close(1008,'Unauthorized')}});

db.prepare('SELECT * FROM tasks WHERE enabled=1').all().forEach(registerTask);
for(const a of db.prepare('SELECT * FROM apps WHERE auto_start=1').all()){try{start(a)}catch(e){console.error('Autostart:',a.name,e.message)}}

const PORT=cfg.port||3000;const HOST=cfg.host||'127.0.0.1';server.listen(PORT,HOST,()=>console.log(`Server Manager M5: http://${HOST}:${PORT}`));
function shutdown(){for(const a of db.prepare('SELECT * FROM apps').all())stop(a,true);for(const c of wss.clients)c.terminate();server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),1500).unref()}
process.on('SIGINT',shutdown);
process.on('SIGTERM',shutdown);
